'use strict'

function removeDuplicates (a) {
  const set = new Set()
  return a.filter(e => !set.has(e) && set.add(e))
}

function subtractArray (a, b) {
  const set = new Set(b)
  return a.filter(x => !set.has(x))
}

function intersectArray (a, b) {
  if (a.length < b.length) {
    return intersectArray(b, a)
  }
  // a.length >= b.length
  const set = new Set(a)
  return b.filter(e => set.has(e))
}

// eslint-disable-next-line no-undef, no-constant-condition
const storage = ((typeof browser !== 'undefined') ? browser : chrome).storage
const KEY_FARM_LIST = 'farmList'
const KEY_FARM_LIST_SIZE = 'farmListSize'
const MAX_LIST_SIZE = 400

/**
 * Queries all hosts in the database.
 * @returns hosts in the database.
 */
async function getFarmList () {
  let q
  // Query segment count.
  q = {}
  q[KEY_FARM_LIST_SIZE] = 0
  const res1 = await storage.sync.get(q)
  const segmentCount = res1[KEY_FARM_LIST_SIZE]
  if (segmentCount === 0) {
    return []
  }
  // Query segments and merge into one.
  q = {}
  q = [...Array(segmentCount).keys()].map(i => KEY_FARM_LIST + i)
  const res2 = await storage.sync.get(q)
  const segments = Object.values(res2)
  return segments.flat()
}

/**
 * Inserts hosts into database.
 * @returns inserted hosts.
  */
async function addHosts (hosts) {
  hosts = removeDuplicates(hosts)
  if (hosts.length === 0) {
    // No new hosts are added so do nothing.
    return []
  }
  // Compute new list.
  const oldList = await getFarmList()
  const newList = removeDuplicates(oldList.concat(hosts))
  if (oldList.length === newList.length) {
    // No new hosts are added so do nothing.
    return []
  }
  // Break list into sections.
  let startIndex = Math.ceil(oldList.length / MAX_LIST_SIZE) - 1
  startIndex = Math.max(startIndex, 0)
  const endIndex = Math.ceil(newList.length / MAX_LIST_SIZE)
  const obj = {}
  for (let i = startIndex; i < endIndex; i++) {
    const index = i * MAX_LIST_SIZE
    obj[KEY_FARM_LIST + i] = newList.slice(index, index + MAX_LIST_SIZE)
  }
  obj[KEY_FARM_LIST_SIZE] = endIndex
  await storage.sync.set(obj)
  return subtractArray(newList, oldList)
}

/**
 * Removes hosts from database.
 * @returns removed hosts.
 */
async function removeHosts (hosts) {
  hosts = removeDuplicates(hosts)
  if (hosts.length === 0) {
    // No hosts are removed so do nothing.
    return []
  }
  // Generate the new list.
  const list = await getFarmList()
  const newList = subtractArray(list, hosts)
  if (newList.length === list.length) {
    // No hosts are removed so do nothing.
    return []
  }
  // Update the entire database.
  const obj = {}
  const segmentCount = Math.ceil(newList.length / MAX_LIST_SIZE)
  for (let i = 0; i < segmentCount; i++) {
    const index = i * MAX_LIST_SIZE
    obj[KEY_FARM_LIST + i] = newList.slice(index, index + MAX_LIST_SIZE)
  }
  obj[KEY_FARM_LIST_SIZE] = segmentCount
  await storage.sync.set(obj)
  return intersectArray(list, hosts)
}

async function tick () {
  return new Promise(res => window.requestAnimationFrame(res))
}

// https://stackoverflow.com/questions/6121203/how-to-do-fade-in-and-fade-out-with-javascript-and-css
async function hideElements (els, fade) {
  if (!fade) {
    els.forEach(el => {
      el.style.display = 'none'
    })
    return
  }
  return new Promise(res => {
    function transitionEndHandler (event) {
      const el = event.target
      el.style.display = 'none'
      res()
    }

    els.forEach(el => {
      el.addEventListener('transitionend', transitionEndHandler, { once: true })
      el.style['transition-property'] = 'opacity'
      el.style['transition-duration'] = '200ms'
      el.style.opacity = '0'
    })
  })
}

// https://stackoverflow.com/questions/6121203/how-to-do-fade-in-and-fade-out-with-javascript-and-css
async function showElements (elements, fade) {
  if (!fade) {
    elements.forEach((element) => {
      element.style.opacity = '1'
      element.style.display = 'block'
    })
    return
  }
  return new Promise((res) => {
    elements.forEach(async (el) => {
      el.style.display = 'block'
      await tick()
      el.addEventListener('webkitTransitionEnd', () => res(), { once: true })
      el.style.opacity = '1'
    })
  })
}

// https://www.w3schools.com/howto/howto_js_check_hidden.asp
function isElementHidden (el) {
  const style = window.getComputedStyle(el)
  return style.display === 'none' || style.visibility === 'hidden'
}

function once (callback) {
  let flag = true
  return (e) => {
    if (flag) {
      flag = false
      callback(e)
    }
    else {
      e.preventDefault()
    }
  }
}

// eslint-disable-next-line no-undef, no-constant-condition
const getI18nMessage = ((typeof browser !== 'undefined') ? browser : chrome).i18n.getMessage

class Terminator {
  constructor (category) {
    this.category = category
  }

  async run () {
    this.markSearchCategory()
    await this.init()
  }

  markSearchCategory () {
    document.body.setAttribute('cft-search-category', this.category)
  }
}

class ListedTerminator extends Terminator {
  async init () {
    // Get farm result nodes and non farm result nodes.
    const farmList = new Set(await getFarmList())
    const resultNodes = this.getResultNodes()
    const farmResultNodes = []
    const nonfarmResultNodes = []
    for (const resultNode of resultNodes) {
      const domain = this.getSourceDomain(resultNode)
      if (farmList.has(domain)) {
        farmResultNodes.push(resultNode)
      }
      else {
        nonfarmResultNodes.push(resultNode)
      }
    }
    // Add class to result nodes.
    resultNodes.forEach(resultNode => resultNode.classList.add('cft-result'))
    if (farmResultNodes.length > 0) {
      // Hide farm result nodes.
      farmResultNodes.forEach(resultNode => resultNode.classList.add('cft-farm-result'))
      hideElements(farmResultNodes, false) // fire and forget
      // Add a hint which allows user to show these results temporarily onto the
      // page.
      this.addShowFarmResultsOnceHint(farmResultNodes.length)
    }
    // Add "Terminate!" button to each search result. Already hidden farm result
    // nodes are excluded.
    nonfarmResultNodes.forEach(e => this.addTerminateHint(e))
  }

  addShowFarmResultsOnceHint (farmCount) {
    const msg = getI18nMessage('showFarmResultsOnce', farmCount.toString())
    const [msgLeft, msgRight] = msg.split('#')
    const buttonText = getI18nMessage('showFarmResultsOneHint')
    const button = this.addShowFarmResultsOnceNode(msgLeft, buttonText, msgRight)
    button.onclick = once(async (e) => {
      e.preventDefault()
      // Add Get blocked results that are going to be shown. Noted that not
      // all hidden result nodes are selected. There may be result nodes that
      // are hidden on page loaded or on user clicks the "Terminate!" button,
      // and only the former ones are selected.
      let blockedResultNodes = this.getResultNodes()
      blockedResultNodes = blockedResultNodes.filter(resultNode => resultNode.classList.contains('cft-farm-result'))
      const determinateHintText = getI18nMessage('determinateHint')
      blockedResultNodes.forEach(resultNode => {
        // Set there title to farm (red).
        // resultNode.classList.add('')
        // this.markResultTitle(resultNode, true)
        // Add a "Determinate" hint to these results.
        const button = this.addHintNode(resultNode, determinateHintText)
        // Mark the result node as shown temporarily
        resultNode.classList.add('cft-farm-result-shown')
        button.onclick = once(async (e) => {
          e.preventDefault()
          // Get other search items linking to same host and show them all.
          const domain = this.getSourceDomain(resultNode)
          const unblockedResultNodes = this.getResultNodes().filter(resultNode => this.getSourceDomain(resultNode) === domain)
          // Since these results are unblocked, we should re-add the
          // "Terminate!" hint to them, and set title to safe (default font).
          unblockedResultNodes.forEach(unblockedResultNode => {
            unblockedResultNode.classList.remove('cft-farm-result', 'cft-farm-result-shown')
            this.addTerminateHint(unblockedResultNode)
          })
          // Remove this host to blocking list
          await removeHosts([domain])
        })
      })
      // Then we show the blocked results and hide the show-once hint.
      await Promise.all([
        showElements(blockedResultNodes, true),
        hideElements([document.getElementById('cft-temp-show')], true)
      ])
    })
  }

  addTerminateHint (resultNode) {
    const domain = this.getSourceDomain(resultNode)
    const hintNode = this.addHintNode(resultNode, getI18nMessage('terminateHint'))
    hintNode.onclick = once(async (e) => {
      e.preventDefault()
      // Get other search items linking to same host and hide them all.
      const resultNodes = this.getResultNodes()
      const nodesToBeHidden = resultNodes.filter(e => this.getSourceDomain(e) === domain)
      await hideElements(nodesToBeHidden, true) // wait for fade effect
      // THEN add undo hints to these nodes
      nodesToBeHidden.forEach(e => this.addUndoHint(e))
      // Add this host to blocking list
      await addHosts([domain])
    })
  }

  addUndoHint (hiddenResultNode) {
    const domain = this.getSourceDomain(hiddenResultNode)
    const undoButton = this.addUndoHintNode(hiddenResultNode, getI18nMessage('undoHint'), getI18nMessage('terminatedMsg', domain))
    undoButton.onclick = once(async (e) => {
      e.preventDefault()
      // Get all undo node for the domain and removes them
      const undoNodes = document.querySelectorAll(`.cft-blocked-hint[cft-domain="${domain}"]`)
      undoNodes.forEach(undoNode => undoNode.remove())
      // Show hidden result nodes that are previous hidden.
      let unblockedResultNodes = this.getResultNodes()
      unblockedResultNodes = unblockedResultNodes.filter(resultNode => this.getSourceDomain(resultNode) === domain)
      unblockedResultNodes = unblockedResultNodes.filter(isElementHidden)
      await showElements(unblockedResultNodes, true)
      // Re-add 'Terminate!' button to these nodes
      unblockedResultNodes.forEach(resultNode => this.addTerminateHint(resultNode))
      // Remove domain from database
      await removeHosts([domain])
    })
  }
}

// Unlisted terminator is used for webpage whose search results are not a
// static list; for example Google Images, which search results are dynamically
// loaded blocks.
// Unlisted terminator does not support terminate or determinate on click
// action. Users must key in their own farm list via the popup. However this
// terminator still allows user to show farm results once.
class UnlistedTerminator extends Terminator {
  async init () {
    const farmList = new Set(await getFarmList())
    // Since search results are dynamically loaded, an mutation observer is
    // needed.
    const ma = new MutationObserver((muts) => {
      for (const mut of muts) {
        for (let i = 0; i < mut.addedNodes.length; i++) {
          const addedNode = mut.addedNodes.item(i)
          if (addedNode instanceof HTMLElement && this.isSearchResult(addedNode)) {
            addedNode.classList.add('cft-result')
            const domain = this.getSourceDomain(addedNode)
            if (farmList.has(domain)) {
              addedNode.classList.add('cft-farm-result')
              // hideElements([addedNode], false) // fire and forget
            }
          }
        }
      }
    })
    const resultContainer = this.getSearchResultWrapper()
    ma.observe(resultContainer, { childList: true })
    // Hide current appeared farm results
    const resultNodes = this.getCurrentSearchResults()
    resultNodes.forEach(e => e.classList.add('cft-result'))
    const farmResultNodes = resultNodes.filter(e => farmList.has(this.getSourceDomain(e)))
    farmResultNodes.forEach(e => e.classList.add('cft-farm-result'))
    // hideElements(farmResultNodes, false) // fire and forget
    // Add option to allow user stops the terminator
    const [msgLeft, buttonText, msgRight] = getI18nMessage('imageTerminatorRunningHint').split('#')
    const cancelButton = this.addCancelTerminatorHint(msgLeft, buttonText, msgRight)
    cancelButton.onclick = once(async (e) => {
      e.preventDefault()
      ma.disconnect()
      const tempHintNode = document.getElementById('cft-temp-show')
      const hiddenFarmImageResults = Array.from(resultContainer.querySelectorAll('.cft-farm-result'))
      hiddenFarmImageResults.forEach(e => e.classList.remove('cft-farm-result'))
      await hideElements([tempHintNode], true)
    })
  }
}

class GoogleImageTerminator extends UnlistedTerminator {
  constructor () {
    super('google-image')
  }

  getSearchResultWrapper () {
    return document.querySelector('.islrc')
  }

  isSearchResult (e) {
    return e.classList.contains('isv-r') &&
            e.classList.contains('PNCib') &&
            e.classList.contains('MSM1fd') &&
            e.classList.contains('BUooTd')
  }

  getCurrentSearchResults () {
    const nodes = document.querySelectorAll('.islrc>.isv-r.PNCib.MSM1fd.BUooTd')
    return Array.from(nodes)
  }

  getSourceDomain (resultNode) {
    return resultNode.querySelector('.fxgdke').textContent
  }

  addCancelTerminatorHint (msgLeft, buttonText, msgRight) {
    const button = document.createElement('a')
    button.href = '#'
    button.classList.add('cft-button')
    button.textContent = buttonText
    const p = document.createElement('p')
    p.append(document.createTextNode(msgLeft), button, document.createTextNode(msgRight))
    p.id = 'cft-temp-show'
    p.classList.add('cft-image-temp-hint')
    const wrapper = document.querySelector('.mJxzWe')
    wrapper.prepend(p)
    return button
  }
}

class GoogleListedTerminator extends ListedTerminator {
  addShowFarmResultsOnceNode (msgLeft, buttonText, msgRight) {
    const a = document.createElement('a')
    a.href = '#'
    a.classList.add('cft-button')
    a.textContent = buttonText
    const leftMessage = document.createTextNode(msgLeft)
    const rightMessage = document.createTextNode(msgRight)
    const hintMessageNode = document.createElement('p')
    hintMessageNode.appendChild(leftMessage)
    hintMessageNode.appendChild(a)
    hintMessageNode.appendChild(rightMessage)
    const hintNode = document.createElement('div')
    hintNode.id = 'cft-temp-show'
    hintNode.classList.add('cft-bottom-hint')
    hintNode.appendChild(hintMessageNode)
    // Add the hint node to the bottom of the page.
    const botStuff = document.getElementById('botstuff')
    botStuff.prepend(hintNode)
    return a
  }
}

function isNewsResultNode (resultNode) {
  return resultNode.classList.contains('MkXWrd')
}

class GoogleWebsiteTerminator extends GoogleListedTerminator {
  constructor () {
    super('google-website')
  }

  getResultNodes () {
    let commonResultNodes = Array.from(document.querySelectorAll('.v7W49e>*'))
    commonResultNodes = commonResultNodes.filter(candidateNode => candidateNode.classList.contains('tF2Cxc') ||
            candidateNode.querySelector('.tF2Cxc') !== null ||
            candidateNode.querySelector('.jtfYYd') !== null)
    const newsResultNodes = Array.from(document.querySelectorAll('.MkXWrd'))
    return commonResultNodes.concat(newsResultNodes)
  }

  getSourceDomain (resultNode) {
    if (isNewsResultNode(resultNode)) {
      // news result node
      const a = resultNode.querySelector('a.WlydOe')
      return a.hostname
    }
    // common result node
    const selector = '.yuRUbf>a:first-child'
    const a = resultNode.querySelector(selector)
    return a.hostname
  }

  addHintNode (resultNode, text) {
    let button = resultNode.querySelector('a.cft-hint')
    // If button already exists, remove it.
    if (button !== null) {
      button.remove()
    }
    // Create button
    button = document.createElement('a')
    button.classList.add('cft-hint', 'cft-button')
    button.textContent = text
    button.href = '#'
    // Add button to the result node.
    if (isNewsResultNode(resultNode)) {
      // news result node
      const wrapper = resultNode.querySelector('.CEMjEf.NUnG9d')
      wrapper.appendChild(button)
    }
    else {
      // common result node
      const titleWrapperNode = resultNode.querySelector('.yuRUbf')
      const titleNode = titleWrapperNode.querySelector('a')
      const subtitleNode = resultNode.querySelector('.B6fmyf')
      const urlNode = subtitleNode.querySelector('.TbwUpd')
      titleWrapperNode.classList.add('cft-result-title-wrapper')
      titleNode.classList.add('cft-result-title')
      subtitleNode.classList.add('cft-result-subtitle')
      urlNode.classList.add('cft-url')
      const hintWrapperNode = subtitleNode.querySelector('.eFM0qc')
      hintWrapperNode.appendChild(button)
    }
    return button
  }

  addUndoHintNode (resultNode, buttonText, undoHintText) {
    const domain = this.getSourceDomain(resultNode)
    // Create undo button. An attribute is added so that we can infer the
    // terminated domain if the user clicks it later.
    const undoButton = document.createElement('a')
    undoButton.setAttribute('cft-domain', domain)
    undoButton.classList.add('cft-hint', 'cft-button')
    undoButton.textContent = buttonText
    // Create undo hint message
    const undoHintNode = document.createElement('span')
    undoHintNode.textContent = undoHintText
    // Create undo node that contains hint and button.
    const undoDiv = document.createElement('div')
    undoDiv.classList.add('cft-blocked-hint')
    undoDiv.classList.add(isNewsResultNode(resultNode) ? 'MkXWrd' : 'g')
    undoDiv.setAttribute('cft-domain', domain)
    undoDiv.appendChild(undoHintNode)
    undoDiv.appendChild(undoButton)
    // Insert undo node next to the (hidden) result node
    resultNode.parentNode.insertBefore(undoDiv, resultNode.nextSibling)
    return undoButton
  }
}

class GoogleNewsTerminator extends GoogleListedTerminator {
  constructor () {
    super('google-news')
  }

  async init () {
    // Since a.href in the result node changes when the user clicks it, we
    // need to preserve the hostname first.
    const resultNodes = this.getResultNodes()
    resultNodes.forEach(resultNode => {
      const a = resultNode.querySelector('a.WlydOe')
      const domain = a.hostname
      resultNode.setAttribute('cft-hostname-preserve', domain)
    })
    super.init()
  }

  getResultNodes () {
    const selector = '.v7W49e>div[data-hveid],.v7W49e g-card div[data-hveid]:not(:only-child)'
    const _resultNodes = document.querySelectorAll(selector)
    const resultNodes = Array.from(_resultNodes)
    return resultNodes
  }

  getSourceDomain (resultNode) {
    return resultNode.getAttribute('cft-hostname-preserve')
  }

  addHintNode (resultNode, text) {
    let button = resultNode.querySelector('a.cft-hint')
    // If button already exists, remove it.
    if (button !== null) {
      button.remove()
    }
    // Create button
    button = document.createElement('a')
    button.classList.add('cft-hint', 'cft-button')
    button.textContent = text
    button.href = '#'
    // Add button to the result node.
    const titleNode = resultNode.querySelector('.mCBkyc.y355M')
    titleNode.classList.add('cft-result-title')
    const sourceNewsNode = resultNode.querySelector('.CEMjEf.NUnG9d')
    sourceNewsNode.appendChild(button)
    return button
  }

  addUndoHintNode (resultNode, buttonText, undoHintText) {
    const domain = this.getSourceDomain(resultNode)
    const parentNode = resultNode.parentElement
    const isInCard = !parentNode.classList.contains('v7W49e')
    // Create undo button. An attribute is added so that we can infer the
    // terminated domain if the user clicks it later.
    const undoButton = document.createElement('a')
    undoButton.setAttribute('cft-domain', domain)
    undoButton.classList.add('cft-hint', 'cft-button')
    undoButton.textContent = buttonText
    // Create undo hint message
    const undoHintNode = document.createElement('span')
    undoHintNode.textContent = undoHintText
    // Create undo node that contains hint and button.
    const undoDiv = document.createElement('div')
    undoDiv.classList.add('cft-blocked-hint', isInCard ? 'cft-in-news-card' : 'cft-is-news-card')
    undoDiv.setAttribute('cft-domain', domain)
    undoDiv.appendChild(undoHintNode)
    undoDiv.appendChild(undoButton)
    // Insert undo node next to the (hidden) result node
    resultNode.parentNode.insertBefore(undoDiv, resultNode.nextSibling)
    return undoButton
  }
}

// This script is executed when google.com/search page is loaded.
// suppress eslint warning
async function init () {
  // https://www.sitepoint.com/get-url-parameters-with-javascript/
  const queryString = window.location.search
  const urlParams = new URLSearchParams(queryString)
  // Check if user is searching website or news.
  const tbm = urlParams.get('tbm')
  let terminator = null
  if (tbm === null) {
    // websites
    terminator = new GoogleWebsiteTerminator()
  }
  else if (tbm === 'isch') {
    // images
    terminator = new GoogleImageTerminator()
  }
  else if (tbm === 'nws') {
    // news
    terminator = new GoogleNewsTerminator()
  }
  if (terminator !== null) {
    await terminator.run()
  }
}

init()
