'use strict'

function removeDuplicates (a) {
  const set = new Set()
  return a.filter(e => !set.has(e) && set.add(e))
}

function subtractArray (a, b) {
  const set = new Set(b)
  return a.filter(x => !set.has(x))
}

function intersectArray (a, b) {
  if (a.length < b.length) {
    return intersectArray(b, a)
  }
  // a.length >= b.length
  const set = new Set(a)
  return b.filter(e => set.has(e))
}

// eslint-disable-next-line no-undef, no-constant-condition
const storage = ((typeof browser !== 'undefined') ? browser : chrome).storage
const KEY_FARM_LIST = 'farmList'
const KEY_FARM_LIST_SIZE = 'farmListSize'
const MAX_LIST_SIZE = 400

/**
 * Queries all hosts in the database.
 * @returns hosts in the database.
 */
async function getFarmList () {
  let q
  // Query segment count.
  q = {}
  q[KEY_FARM_LIST_SIZE] = 0
  const res1 = await storage.sync.get(q)
  const segmentCount = res1[KEY_FARM_LIST_SIZE]
  if (segmentCount === 0) {
    return []
  }
  // Query segments and merge into one.
  q = {}
  q = [...Array(segmentCount).keys()].map(i => KEY_FARM_LIST + i)
  const res2 = await storage.sync.get(q)
  const segments = Object.values(res2)
  return segments.flat()
}

/**
 * Inserts hosts into database.
 * @returns inserted hosts.
  */
async function addHosts (hosts) {
  hosts = removeDuplicates(hosts)
  if (hosts.length === 0) {
    // No new hosts are added so do nothing.
    return []
  }
  // Compute new list.
  const oldList = await getFarmList()
  const newList = removeDuplicates(oldList.concat(hosts))
  if (oldList.length === newList.length) {
    // No new hosts are added so do nothing.
    return []
  }
  // Break list into sections.
  let startIndex = Math.ceil(oldList.length / MAX_LIST_SIZE) - 1
  startIndex = Math.max(startIndex, 0)
  const endIndex = Math.ceil(newList.length / MAX_LIST_SIZE)
  const obj = {}
  for (let i = startIndex; i < endIndex; i++) {
    const index = i * MAX_LIST_SIZE
    obj[KEY_FARM_LIST + i] = newList.slice(index, index + MAX_LIST_SIZE)
  }
  obj[KEY_FARM_LIST_SIZE] = endIndex
  await storage.sync.set(obj)
  return subtractArray(newList, oldList)
}

/**
 * Removes hosts from database.
 * @returns removed hosts.
 */
async function removeHosts (hosts) {
  hosts = removeDuplicates(hosts)
  if (hosts.length === 0) {
    // No hosts are removed so do nothing.
    return []
  }
  // Generate the new list.
  const list = await getFarmList()
  const newList = subtractArray(list, hosts)
  if (newList.length === list.length) {
    // No hosts are removed so do nothing.
    return []
  }
  // Update the entire database.
  const obj = {}
  const segmentCount = Math.ceil(newList.length / MAX_LIST_SIZE)
  for (let i = 0; i < segmentCount; i++) {
    const index = i * MAX_LIST_SIZE
    obj[KEY_FARM_LIST + i] = newList.slice(index, index + MAX_LIST_SIZE)
  }
  obj[KEY_FARM_LIST_SIZE] = segmentCount
  await storage.sync.set(obj)
  return intersectArray(list, hosts)
}

function isValidHostname (s) {
  return /^(([a-z0-9]|[a-z0-9][a-z0-9-]*[a-z0-9])\.)+([a-z0-9]|[a-z0-9][a-z0-9-]*[a-z0-9])$/.test(s)
}

function isValidUrl (s) {
  return /^http[s]{0,1}:\/\/.*?\/.*$/.test(s)
}

// eslint-disable-next-line no-undef, no-constant-condition
const getI18nMessage = ((typeof browser !== 'undefined') ? browser : chrome).i18n.getMessage

function parseString (s) {
  // license: The MIT License, Copyright (c) 2016-2019 YUKI "Piro" Hiroshi
  // original: http://github.com/piroor/webextensions-lib-l10n
  if (s === null) {
    return null
  }
  return s.replace(/__MSG_([@\w]+)__/g, (matched, key) => {
    return getI18nMessage(key) || matched
  })
}

function parseDocument () {
  const texts = document.evaluate('descendant::text()[contains(self::text(), "__MSG_")]', document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null)
  for (let i = 0, maxi = texts.snapshotLength; i < maxi; i++) {
    const text = texts.snapshotItem(i)
    text.nodeValue = parseString(text.nodeValue)
  }
  const attributes = document.evaluate('descendant::*/attribute::*[contains(., "__MSG_")]', document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null)
  for (let i = 0, maxi = attributes.snapshotLength; i < maxi; i++) {
    const attribute = attributes.snapshotItem(i)
    attribute.nodeValue = parseString(attribute.nodeValue)
  }
}

const EMOJI_PASS = '😀'
const EMOJI_DUPLICATED = '🤨'
const EMOJI_FOUL = '😭'
const textarea = document.getElementById('txtArea')
const btnAdd = document.getElementById('btnAdd')
const btnDelete = document.getElementById('btnDelete')
const btnView = document.getElementById('btnViewAll')
const divHint = document.getElementById('hint')

function actionResult (hostArray, passedHosts) {
  return hostArray.map((value, index) => {
    if (value === null) {
      return EMOJI_FOUL
    }
    if (!passedHosts.includes(value)) {
      return EMOJI_DUPLICATED
    }
    return hostArray.indexOf(value) === index ? EMOJI_PASS : EMOJI_DUPLICATED
  })
}

function updateHint (title, content) {
  const pTitle = document.createElement('p')
  pTitle.textContent = title
  const pHint = document.createElement('p')
  let first = true
  for (const contentLine of content) {
    if (first) {
      first = false
    }
    else {
      pHint.appendChild(document.createElement('br'))
    }
    pHint.appendChild(document.createTextNode(contentLine))
  }
  divHint.replaceChildren(pTitle, pHint)
}

async function onAddHostsListener () {
  if (isTextAreaEmpty()) {
    return
  }
  const lines = textarea.value.split('\n').map(str => str.trim()).filter(isValidLine)
  if (lines.length === 0) {
    return
  }
  const hosts = lines.map(getHostnameFromLine)
  const validHosts = hosts.filter(h => h !== null)
  const newlyBlockedHosts = await addHosts(validHosts)
  const resultList = actionResult(hosts, newlyBlockedHosts)
  const text = lines.map((line, index) => `${resultList[index]} ${line}`).join('\n')
  const nNewlyBlocked = resultList.filter(e => e === EMOJI_PASS).length
  let title
  if (nNewlyBlocked === lines.length) {
    title = getI18nMessage('allAdded', nNewlyBlocked.toString())
  }
  else if (nNewlyBlocked === 0) {
    title = getI18nMessage('nothingChanged')
  }
  else {
    title = getI18nMessage('notAllAdded', nNewlyBlocked.toString())
  }
  const hint = getI18nMessage('addActionHint', [EMOJI_PASS, EMOJI_DUPLICATED, EMOJI_FOUL])
  textarea.value = text
  updateHint(title, hint.split('#'))
}

async function onRemoveHostsListener () {
  if (isTextAreaEmpty()) {
    return
  }
  const lines = textarea.value.split('\n').map(str => str.trim()).filter(isValidLine)
  if (lines.length === 0) {
    return
  }
  const hosts = lines.map(getHostnameFromLine)
  const validHosts = hosts.filter(h => h !== null)
  const removed = await removeHosts(validHosts)
  const resultList = actionResult(hosts, removed)
  const text = lines.map((line, index) => `${resultList[index]} ${line}`).join('\n')
  const nNewlyUnblocked = resultList.filter(e => e === EMOJI_PASS).length
  let title
  if (nNewlyUnblocked === lines.length) {
    title = getI18nMessage('allRemoved', nNewlyUnblocked.toString())
  }
  else if (nNewlyUnblocked === 0) {
    title = getI18nMessage('nothingChanged')
  }
  else {
    title = getI18nMessage('notAllRemoved', nNewlyUnblocked.toString())
  }
  const hint = getI18nMessage('removeActionHint', [EMOJI_PASS, EMOJI_DUPLICATED, EMOJI_FOUL])
  textarea.value = text
  updateHint(title, hint.split('#'))
}

async function onViewAllHostsListener () {
  let list = await getFarmList()
  list = list.reverse()
  let msg
  if (list.length === 0) {
    msg = `# ${getI18nMessage('emptyList')}`
  }
  else {
    const fix = `# ${list.length}`
    msg = `${fix}\n${list.map(h => `${EMOJI_PASS} ${h}`).join('\n')}\n${fix}`
  }
  textarea.value = msg
}

// Queries the hostname from an url or hostname; returns null if this string is
// an invalid hostname.
function getHostnameFromLine (text) {
  // Trim the string
  text = text.trim().toLowerCase()
  let hostname
  // If this is an url, that is, start with http(s), gets its hostname.
  if (isValidUrl(text)) {
    const fromIndex = text.indexOf('://') + 3
    const toIndex = text.indexOf('/', fromIndex)
    hostname = text.substring(fromIndex, toIndex)
  }
  // Otherwise considers it to be a hostname
  else {
    hostname = text
  }
  return isValidHostname(hostname) ? hostname : null
}

// Queries if a line does not start with '#' or emojis.
function isValidLine (line) {
  return line.length &&
        !line.startsWith('#') &&
        !line.startsWith(EMOJI_PASS) &&
        !line.startsWith(EMOJI_DUPLICATED) &&
        !line.startsWith(EMOJI_FOUL)
}

// Queries if the textarea is empty. That is, contains any line that is not
// empty or not starts with '#' or emojis.
function isTextAreaEmpty () {
  return textarea.value.split('\n').filter(isValidLine).length === 0
}

// init
btnAdd.onclick = onAddHostsListener
btnDelete.onclick = onRemoveHostsListener
btnView.onclick = onViewAllHostsListener
parseDocument()
